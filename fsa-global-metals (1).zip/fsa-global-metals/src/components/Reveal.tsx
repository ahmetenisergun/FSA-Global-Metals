import {
  createElement,
  type HTMLAttributes,
  type ElementType,
  type Ref,
} from "react";
import { useReveal } from "@/hooks/use-reveal";
import { cn } from "@/lib/utils";

interface RevealProps extends HTMLAttributes<HTMLElement> {
  as?: ElementType;
  delay?: number;
  /** translate-from direction. default: up */
  from?: "up" | "left" | "right";
}

export function Reveal({
  as = "div",
  delay = 0,
  from = "up",
  className,
  style,
  children,
  ...rest
}: RevealProps) {
  const { ref, visible } = useReveal<HTMLElement>();
  const fromCls =
    from === "left"
      ? "reveal-left"
      : from === "right"
        ? "reveal-right"
        : "reveal";
  return createElement(
    as as ElementType,
    {
      ref: ref as Ref<HTMLElement>,
      className: cn(fromCls, visible && "is-visible", className),
      style: { transitionDelay: `${delay}ms`, ...style },
      ...rest,
    },
    children,
  );
}
