import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

const NAV = [
  { id: "history", label: "History" },
  { id: "sourcing", label: "Sourcing" },
  { id: "inventory", label: "Inventory" },
  { id: "logistics", label: "Logistics" },
  { id: "contact", label: "Contact" },
] as const;

export function SiteHeader({ overlay = false }: { overlay?: boolean }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<string>("");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const ids = NAV.map((n) => n.id);
    const els = ids
      .map((id) => document.getElementById(id))
      .filter((e): e is HTMLElement => !!e);
    if (!els.length) return;

    const obs = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) setActive(e.target.id);
        }
      },
      { rootMargin: "-40% 0px -55% 0px", threshold: 0 },
    );
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  const handleAnchor = (
    e: React.MouseEvent<HTMLAnchorElement>,
    id: string,
  ) => {
    e.preventDefault();
    setOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
      history.replaceState(null, "", `#${id}`);
    }
  };

  const onDark = overlay && !scrolled;

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-background/85 backdrop-blur-md border-b border-border"
          : overlay
            ? "bg-transparent"
            : "bg-background",
      )}
    >
      <div className="mx-auto max-w-7xl px-6 md:px-10 h-16 flex items-center justify-between">
        <Link
          to="/"
          onClick={(e) => {
            if (window.scrollY > 0) {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: "smooth" });
            }
          }}
          className={cn(
            "text-[11px] tracking-[0.28em] font-medium uppercase",
            onDark ? "text-white" : "text-foreground",
          )}
        >
          FSA <span className="text-turquoise">Global</span> Metals
        </Link>

        <nav className="hidden md:flex items-center gap-8">
          {NAV.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              onClick={(e) => handleAnchor(e, item.id)}
              data-status={active === item.id ? "active" : undefined}
              className={cn(
                "nav-link text-[12px] tracking-[0.18em] uppercase font-light transition-colors",
                onDark
                  ? "text-white/80 hover:text-white"
                  : "text-foreground/70 hover:text-foreground",
              )}
            >
              {item.label}
            </a>
          ))}
        </nav>

        <button
          aria-label="Toggle menu"
          className={cn(
            "md:hidden h-8 w-8 flex flex-col justify-center items-center gap-1.5",
            onDark ? "text-white" : "text-foreground",
          )}
          onClick={() => setOpen((v) => !v)}
        >
          <span
            className={cn(
              "block h-px w-5 bg-current transition-transform",
              open && "translate-y-[3px] rotate-45",
            )}
          />
          <span
            className={cn(
              "block h-px w-5 bg-current transition-transform",
              open && "-translate-y-[3px] -rotate-45",
            )}
          />
        </button>
      </div>

      {open && (
        <div className="md:hidden border-t border-border bg-background">
          <nav className="flex flex-col px-6 py-4 gap-3">
            {NAV.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(e) => handleAnchor(e, item.id)}
                className="nav-link text-sm tracking-[0.18em] uppercase font-light text-foreground/80"
              >
                {item.label}
              </a>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
