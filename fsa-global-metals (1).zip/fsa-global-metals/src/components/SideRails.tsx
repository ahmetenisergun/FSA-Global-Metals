import { useScrollY } from "@/hooks/use-scroll-progress";
import { useEffect, useState } from "react";

/**
 * Decorative left/right side rails that animate with scroll:
 *  - Vertical hairlines that grow as the page scrolls
 *  - Stacked tick marks that drift up at parallax speed
 *  - A small running counter (scroll % of page)
 *  - Floating accent dots that travel along the sides
 *
 * Honors prefers-reduced-motion.
 */
export function SideRails() {
  const scrollY = useScrollY();
  const [docHeight, setDocHeight] = useState(1);
  const [reduce, setReduce] = useState(false);

  useEffect(() => {
    const calc = () =>
      setDocHeight(
        Math.max(
          1,
          document.documentElement.scrollHeight - window.innerHeight,
        ),
      );
    calc();
    window.addEventListener("resize", calc);
    return () => window.removeEventListener("resize", calc);
  }, []);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReduce(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);

  const progress = Math.min(1, Math.max(0, scrollY / docHeight));
  const pct = Math.round(progress * 100);
  const drift = reduce ? 0 : scrollY * 0.25;

  // 14 tick marks evenly spread along the rail
  const ticks = Array.from({ length: 14 }, (_, i) => i);

  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 z-40 hidden md:block"
    >
      {/* LEFT RAIL */}
      <div className="absolute left-4 lg:left-6 top-0 bottom-0 w-[58px]">
        {/* Vertical hairline that fills as you scroll */}
        <div className="absolute left-[28px] top-[12vh] bottom-[12vh] w-px bg-border/60 overflow-hidden">
          <div
            className="absolute top-0 left-0 w-full bg-foreground origin-top"
            style={{
              height: "100%",
              transform: `scaleY(${progress})`,
              transformOrigin: "top",
              transition: reduce ? "none" : "transform 120ms linear",
            }}
          />
        </div>

        {/* Drifting tick marks */}
        <div
          className="absolute left-[20px] top-[12vh] bottom-[12vh] w-4"
          style={{
            transform: `translateY(${-drift}px)`,
          }}
        >
          {ticks.map((i) => (
            <div
              key={i}
              className="absolute left-0 h-px bg-foreground/30"
              style={{
                top: `${(i * 100) / ticks.length}%`,
                width: i % 4 === 0 ? "16px" : "8px",
                background:
                  i % 4 === 0
                    ? "var(--color-foreground)"
                    : "color-mix(in oklab, var(--color-foreground) 25%, transparent)",
              }}
            />
          ))}
        </div>

        {/* Running counter at top */}
        <div
          className="absolute left-0 top-6 -rotate-90 origin-top-left translate-y-6 text-[10px] tracking-[0.32em] uppercase font-light text-foreground/70"
          style={{ transform: "rotate(-90deg) translate(-100%, 0)" }}
        >
          {String(pct).padStart(2, "0")} / 100
        </div>

        {/* Vertical label at bottom */}
        <div
          className="absolute left-0 bottom-6 origin-bottom-left text-[10px] tracking-[0.32em] uppercase font-light text-turquoise"
          style={{ transform: "rotate(-90deg) translate(0, 100%)" }}
        >
          Scroll
        </div>
      </div>

      {/* RIGHT RAIL */}
      <div className="absolute right-4 lg:right-6 top-0 bottom-0 w-[58px]">
        {/* Vertical hairline */}
        <div className="absolute right-[28px] top-[12vh] bottom-[12vh] w-px bg-border/60 overflow-hidden">
          <div
            className="absolute bottom-0 left-0 w-full bg-gold/80 origin-bottom"
            style={{
              height: "100%",
              transform: `scaleY(${progress})`,
              transformOrigin: "bottom",
              transition: reduce ? "none" : "transform 120ms linear",
            }}
          />
        </div>

        {/* Drifting numbered markers (opposite direction) */}
        <div
          className="absolute right-[20px] top-[12vh] bottom-[12vh] w-10"
          style={{
            transform: `translateY(${drift * 0.6}px)`,
          }}
        >
          {ticks.map((i) => (
            <div
              key={i}
              className="absolute right-0 flex items-center gap-2"
              style={{
                top: `${(i * 100) / ticks.length}%`,
              }}
            >
              {i % 3 === 0 && (
                <span className="text-[9px] tracking-[0.2em] text-foreground/40 font-light tabular-nums">
                  {String(i * 7).padStart(3, "0")}
                </span>
              )}
              <div
                className="h-px bg-foreground/30"
                style={{
                  width: i % 3 === 0 ? "16px" : "6px",
                }}
              />
            </div>
          ))}
        </div>

        {/* Floating accent dot — position follows scroll */}
        <div
          className="absolute right-[24px] h-2 w-2 rounded-full bg-turquoise"
          style={{
            top: `calc(12vh + ${progress * 76}vh)`,
            boxShadow: "0 0 12px var(--color-turquoise)",
            transition: reduce ? "none" : "top 120ms linear",
          }}
        />

        {/* Vertical label */}
        <div
          className="absolute right-0 top-6 origin-top-right text-[10px] tracking-[0.32em] uppercase font-light text-foreground/70"
          style={{ transform: "rotate(90deg) translate(100%, 0)" }}
        >
          FSA · 2024
        </div>
      </div>
    </div>
  );
}
