import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/logistics")({
  head: () => ({
    meta: [
      { title: "Logistics — FSA Global Metals" },
      {
        name: "description",
        content: "Redirecting to the Logistics section on the FSA Global Metals landing page.",
      },
    ],
  }),
  component: LogisticsRedirect,
});

function LogisticsRedirect() {
  useEffect(() => {
    window.location.replace("/#logistics");
  }, []);

  return null;
}
