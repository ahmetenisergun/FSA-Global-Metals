import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/inventory")({
  head: () => ({
    meta: [
      { title: "Inventory — FSA Global Metals" },
      {
        name: "description",
        content: "Redirecting to the Inventory section on the FSA Global Metals landing page.",
      },
    ],
  }),
  component: InventoryRedirect,
});

function InventoryRedirect() {
  useEffect(() => {
    window.location.replace("/#inventory");
  }, []);

  return null;
}
