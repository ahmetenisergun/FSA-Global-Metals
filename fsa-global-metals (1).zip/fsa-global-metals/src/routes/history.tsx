import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/history")({
  head: () => ({
    meta: [
      { title: "History — FSA Global Metals" },
      {
        name: "description",
        content: "Redirecting to the History section on the FSA Global Metals landing page.",
      },
    ],
  }),
  component: HistoryRedirect,
});

function HistoryRedirect() {
  useEffect(() => {
    window.location.replace("/#history");
  }, []);

  return null;
}
