import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/sourcing")({
  head: () => ({
    meta: [
      { title: "Sourcing — FSA Global Metals" },
      {
        name: "description",
        content: "Redirecting to the Sourcing section on the FSA Global Metals landing page.",
      },
    ],
  }),
  component: SourcingRedirect,
});

function SourcingRedirect() {
  useEffect(() => {
    window.location.replace("/#sourcing");
  }, []);

  return null;
}
