import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Reveal } from "@/components/Reveal";
import { useScrollY } from "@/hooks/use-scroll-progress";
import { cn } from "@/lib/utils";
import heroVideoUrl from "@/assets/hero.mp4?url";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FSA Global Metals — Sourcing · Supplying · Exporting" },
      {
        name: "description",
        content:
          "Global sourcing, supplying and exporting of high-quality metals and raw materials.",
      },
      { property: "og:title", content: "FSA Global Metals" },
      {
        property: "og:description",
        content: "Sourcing · Supplying · Exporting.",
      },
    ],
  }),
  component: Index,
});

/* ---------------- DATA ---------------- */

const MILESTONES = [
  { year: "2008", text: "Founded as a regional metals trader." },
  { year: "2013", text: "Expanded sourcing operations into Africa and Asia." },
  { year: "2017", text: "Opened European logistics corridor." },
  {
    year: "2021",
    text: "Established direct relationships with refineries worldwide.",
  },
  {
    year: "2024",
    text: "Operating across four continents with industrial clients.",
  },
];

const STEPS = [
  { n: "01", title: "Identify", text: "Mapping verified producers and refineries at origin." },
  { n: "02", title: "Verify", text: "Independent assay, provenance and compliance checks." },
  { n: "03", title: "Deliver", text: "Coordinated logistics from mine to industrial client." },
];

const REGIONS = ["Africa", "Asia", "Europe", "Americas"];

const METALS = [
  { symbol: "Sb", name: "Antimony", spec: "Ingots · 99.65%+", accent: "turquoise" as const },
  { symbol: "Cu", name: "Copper", spec: "Cathodes · 99.99%", accent: "turquoise" as const },
  { symbol: "Zn", name: "Zinc", spec: "SHG ingots · 99.995%", accent: "turquoise" as const },
  { symbol: "Au", name: "Gold", spec: "Bullion · 99.99%", accent: "gold" as const },
  { symbol: "Ag", name: "Silver", spec: "Granules · 99.9%", accent: "turquoise" as const },
];

const CAPABILITIES = [
  { title: "Sea", text: "Bulk and containerised ocean freight on global routes." },
  { title: "Air", text: "Time-critical and high-value air freight worldwide." },
  { title: "Warehousing", text: "Bonded and free storage at strategic hubs." },
  { title: "Customs", text: "Compliant clearance, documentation and origin handling." },
];

const RFQ_METALS = ["Antimony", "Copper", "Zinc", "Gold", "Silver", "Other"] as const;
const UNITS = ["kg", "tonnes", "oz"] as const;

const rfqSchema = z.object({
  name: z.string().trim().min(2, "Required").max(80),
  company: z.string().trim().min(2, "Required").max(120),
  email: z.string().trim().email("Invalid email").max(160),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  metal: z.enum(RFQ_METALS),
  quantity: z.coerce.number().positive("Must be > 0").max(1_000_000),
  unit: z.enum(UNITS),
  destination: z.string().trim().min(2, "Required").max(120),
  message: z.string().trim().max(1000).optional().or(z.literal("")),
});
type RfqValues = z.infer<typeof rfqSchema>;

/* ---------------- PAGE ---------------- */

function Index() {
  return (
    <div className="relative bg-background text-foreground">
      <Hero />
      <SectionDivider label="01 — History" />
      <HistorySection />
      <SectionDivider label="02 — Sourcing" />
      <SourcingSection />
      <SectionDivider label="03 — Inventory" />
      <InventorySection />
      <SectionDivider label="04 — Logistics" />
      <LogisticsSection />
      <SectionDivider label="05 — Contact" />
      <ContactSection />
      <FooterStrip />
    </div>
  );
}

/* ---------------- HERO ---------------- */

function Hero() {
  const y = useScrollY();
  const vh = typeof window !== "undefined" ? window.innerHeight : 800;
  const clamped = Math.min(y, vh);
  const videoTransform = `translate3d(0, ${clamped * 0.3}px, 0) scale(${1 + clamped * 0.0001})`;
  const contentOpacity = Math.max(0, 1 - y / (vh * 0.6));

  return (
    <section className="relative h-screen w-full overflow-hidden bg-[#0B0B0C] text-white">
      <div
        className="absolute inset-0"
        style={{ transform: videoTransform, willChange: "transform" }}
      >
        <video
          src={heroVideoUrl}
          autoPlay
          loop
          muted
          playsInline
          preload="auto"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-black/35" />
      </div>

      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 50%, rgba(0,0,0,0.7) 100%)",
        }}
      />

      {/* bottom gradient — smooth handoff into the page */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 bottom-0 h-40"
        style={{
          background:
            "linear-gradient(to bottom, transparent, var(--color-background))",
        }}
      />

      <div
        className="relative z-10 h-full flex flex-col items-center justify-center px-6 text-center"
        style={{ opacity: contentOpacity }}
      >
        <p className="text-[10px] md:text-[11px] tracking-[0.5em] uppercase font-light text-white/70">
          FSA Global Metals
        </p>
        <h1 className="mt-8 text-4xl md:text-7xl lg:text-8xl font-extralight tracking-tight text-white max-w-4xl leading-[1.05]">
          Pure metals,
          <br />
          delivered <span className="text-turquoise italic font-light">globally</span>.
        </h1>
        <p className="mt-8 text-[10px] md:text-[11px] tracking-[0.32em] uppercase font-light text-white/75">
          Sourcing <span className="text-turquoise mx-2">·</span> Supplying
          <span className="text-turquoise mx-2">·</span> Exporting
        </p>
      </div>

      {/* Scroll cue */}
      <div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-3"
        style={{ opacity: contentOpacity }}
      >
        <span className="text-[9px] tracking-[0.4em] uppercase text-white/60 font-light">
          Scroll
        </span>
        <span className="block h-10 w-px bg-white/40 animate-pulse" />
      </div>
    </section>
  );
}

/* ---------------- DIVIDER ---------------- */

function SectionDivider({ label }: { label: string }) {
  return (
    <div className="mx-auto max-w-7xl px-6 md:px-10">
      <Reveal className="flex items-center gap-6 py-12 md:py-16">
        <span className="text-[10px] md:text-[11px] tracking-[0.4em] uppercase font-light text-muted-foreground tabular-nums">
          {label}
        </span>
        <span className="flex-1 h-px bg-border" />
      </Reveal>
    </div>
  );
}

/* ---------------- HISTORY ---------------- */

function HistorySection() {
  return (
    <section
      id="history"
      className="mx-auto max-w-5xl px-6 md:px-10 py-12 md:py-20 scroll-mt-24"
    >
      <Reveal from="left">
        <p className="text-[11px] tracking-[0.28em] uppercase text-muted-foreground font-light">
          History
        </p>
        <h2 className="mt-4 text-3xl md:text-5xl font-light tracking-tight text-foreground max-w-2xl leading-tight">
          A measured path from regional trader to global metals house.
        </h2>
      </Reveal>

      <div className="mt-20 md:mt-28 relative">
        <div
          className="absolute left-[88px] md:left-[120px] top-2 bottom-2 w-px bg-border"
          aria-hidden
        />
        <ul className="space-y-12 md:space-y-16">
          {MILESTONES.map((m, i) => (
            <Reveal
              as="li"
              key={m.year}
              delay={i * 80}
              from={i % 2 === 0 ? "left" : "right"}
              className="flex items-start gap-8 md:gap-12"
            >
              <span className="w-[72px] md:w-[100px] shrink-0 text-right text-gold text-sm md:text-base tracking-[0.18em] font-light">
                {m.year}
              </span>
              <span
                className="mt-2 h-1.5 w-1.5 rounded-full bg-foreground shrink-0"
                aria-hidden
              />
              <p className="text-base md:text-lg font-light text-foreground/90 max-w-xl leading-relaxed">
                {m.text}
              </p>
            </Reveal>
          ))}
        </ul>
      </div>

      <Reveal className="mt-20 md:mt-28 border-t border-border pt-10">
        <ul className="flex flex-wrap items-center justify-center gap-x-12 gap-y-4 text-[11px] md:text-xs tracking-[0.32em] uppercase font-light text-foreground">
          <li>Integrity</li>
          <li className="text-turquoise">·</li>
          <li>Precision</li>
          <li className="text-turquoise">·</li>
          <li>Reach</li>
        </ul>
      </Reveal>
    </section>
  );
}

/* ---------------- SOURCING ---------------- */

function SourcingSection() {
  return (
    <section
      id="sourcing"
      className="mx-auto max-w-6xl px-6 md:px-10 py-12 md:py-20 scroll-mt-24"
    >
      <Reveal from="right">
        <p className="text-[11px] tracking-[0.28em] uppercase text-muted-foreground font-light">
          Sourcing
        </p>
        <h2 className="mt-4 text-3xl md:text-5xl font-light tracking-tight text-foreground max-w-2xl leading-tight">
          Direct relationships at origin — with full chain-of-custody control.
        </h2>
      </Reveal>

      <div className="mt-20 md:mt-28 grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-6">
        {STEPS.map((s, i) => (
          <Reveal
            key={s.n}
            delay={i * 120}
            from={i === 0 ? "left" : i === 2 ? "right" : "up"}
            className="relative"
          >
            <div className="flex items-baseline gap-4">
              <span className="text-xs tracking-[0.2em] text-muted-foreground font-light">
                {s.n}
              </span>
              {i < STEPS.length - 1 && (
                <span
                  className="hidden md:inline-block text-turquoise text-lg absolute right-0 top-1"
                  aria-hidden
                >
                  →
                </span>
              )}
            </div>
            <h3 className="mt-6 text-2xl font-light tracking-tight text-foreground">
              {s.title}
            </h3>
            <p className="mt-3 text-sm md:text-base font-light leading-relaxed text-foreground/70 max-w-xs">
              {s.text}
            </p>
          </Reveal>
        ))}
      </div>

      <Reveal className="mt-20 md:mt-28 border-t border-border pt-10">
        <p className="text-[11px] tracking-[0.28em] uppercase text-muted-foreground font-light">
          Coverage
        </p>
        <ul className="mt-6 flex flex-wrap items-center gap-x-10 gap-y-4 text-base md:text-lg font-light text-foreground">
          {REGIONS.map((r, i) => (
            <li key={r} className="flex items-center gap-10">
              <span>{r}</span>
              {i < REGIONS.length - 1 && (
                <span className="text-turquoise" aria-hidden>·</span>
              )}
            </li>
          ))}
        </ul>
      </Reveal>
    </section>
  );
}

/* ---------------- INVENTORY ---------------- */

function InventorySection() {
  return (
    <section
      id="inventory"
      className="mx-auto max-w-6xl px-6 md:px-10 py-12 md:py-20 scroll-mt-24"
    >
      <Reveal from="left">
        <p className="text-[11px] tracking-[0.28em] uppercase text-muted-foreground font-light">
          Inventory
        </p>
        <h2 className="mt-4 text-3xl md:text-5xl font-light tracking-tight text-foreground max-w-2xl leading-tight">
          Pure metals and raw materials, refined to industrial specification.
        </h2>
      </Reveal>

      <div className="mt-20 md:mt-28 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border border border-border">
        {METALS.map((m, i) => (
          <Reveal
            key={m.symbol}
            delay={i * 80}
            from={i % 3 === 0 ? "left" : i % 3 === 2 ? "right" : "up"}
            className="bg-background p-8 md:p-10 group transition-colors hover:bg-secondary/50"
          >
            <div className="flex items-start justify-between">
              <span
                className={cn(
                  "text-5xl md:text-6xl font-extralight tracking-tight",
                  m.accent === "gold" ? "text-gold" : "text-turquoise",
                )}
              >
                {m.symbol}
              </span>
              <span className="text-[10px] tracking-[0.28em] uppercase text-muted-foreground font-light mt-2">
                {String(i + 1).padStart(2, "0")}
              </span>
            </div>
            <h3 className="mt-10 text-xl font-light tracking-tight text-foreground">
              {m.name}
            </h3>
            <p className="mt-2 text-sm font-light text-foreground/60">{m.spec}</p>
          </Reveal>
        ))}

        <div className="hidden lg:block bg-background p-8 md:p-10">
          <p className="text-[11px] tracking-[0.28em] uppercase text-muted-foreground font-light">
            Other metals
          </p>
          <p className="mt-4 text-sm font-light text-foreground/70 leading-relaxed">
            Additional metals and alloys sourced on request.
          </p>
        </div>
      </div>

      <Reveal className="mt-12 text-center">
        <p className="text-xs md:text-sm tracking-[0.18em] uppercase font-light text-muted-foreground">
          Contact us for current availability.
        </p>
      </Reveal>
    </section>
  );
}

/* ---------------- LOGISTICS ---------------- */

function LogisticsSection() {
  return (
    <section
      id="logistics"
      className="mx-auto max-w-6xl px-6 md:px-10 py-12 md:py-20 scroll-mt-24"
    >
      <Reveal from="right">
        <p className="text-[11px] tracking-[0.28em] uppercase text-muted-foreground font-light">
          Logistics
        </p>
        <h2 className="mt-4 text-3xl md:text-5xl font-light tracking-tight text-foreground max-w-2xl leading-tight">
          From origin to destination — a single coordinated chain.
        </h2>
      </Reveal>

      <div className="mt-20 md:mt-28 grid grid-cols-2 md:grid-cols-4 gap-px bg-border border border-border">
        {CAPABILITIES.map((c, i) => (
          <Reveal
            key={c.title}
            delay={i * 90}
            from={i < 2 ? "left" : "right"}
            className="bg-background p-6 md:p-8"
          >
            <h3 className="text-lg font-light tracking-tight text-foreground">
              {c.title}
            </h3>
            <p className="mt-3 text-xs md:text-sm font-light leading-relaxed text-foreground/65">
              {c.text}
            </p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ---------------- CONTACT (RFQ) ---------------- */

function ContactSection() {
  const [submitting, setSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<RfqValues>({
    resolver: zodResolver(rfqSchema),
    defaultValues: { metal: "Copper", unit: "tonnes" },
  });

  const onSubmit = async (values: RfqValues) => {
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 600));
    setSubmitting(false);
    toast.success("RFQ received", {
      description: `Thank you, ${values.name}. We will respond within 24 hours.`,
      style: { borderColor: "var(--color-gold)" },
    });
    reset();
  };

  return (
    <section
      id="contact"
      className="mx-auto max-w-5xl px-6 md:px-10 py-12 md:py-24 scroll-mt-24"
    >
      <Reveal from="left">
        <p className="text-[11px] tracking-[0.28em] uppercase text-muted-foreground font-light">
          Request for Quote
        </p>
        <h2 className="mt-4 text-3xl md:text-5xl font-light tracking-tight text-foreground max-w-2xl leading-tight">
          Tell us what you need.
        </h2>
      </Reveal>

      <Reveal delay={120}>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="mt-16 md:mt-20 grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-8"
          noValidate
        >
          <Field label="Name" error={errors.name?.message}>
            <input className={inputCls} {...register("name")} autoComplete="name" />
          </Field>
          <Field label="Company" error={errors.company?.message}>
            <input className={inputCls} {...register("company")} autoComplete="organization" />
          </Field>
          <Field label="Email" error={errors.email?.message}>
            <input className={inputCls} type="email" {...register("email")} autoComplete="email" />
          </Field>
          <Field label="Phone" error={errors.phone?.message}>
            <input className={inputCls} {...register("phone")} autoComplete="tel" />
          </Field>

          <Field label="Metal" error={errors.metal?.message}>
            <select className={inputCls} {...register("metal")}>
              {RFQ_METALS.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </Field>

          <div className="grid grid-cols-2 gap-4">
            <Field label="Quantity" error={errors.quantity?.message}>
              <input
                className={inputCls}
                type="number"
                step="any"
                min="0"
                {...register("quantity")}
              />
            </Field>
            <Field label="Unit" error={errors.unit?.message}>
              <select className={inputCls} {...register("unit")}>
                {UNITS.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
            </Field>
          </div>

          <Field label="Destination" error={errors.destination?.message}>
            <input
              className={inputCls}
              {...register("destination")}
              placeholder="Port / city / country"
            />
          </Field>

          <div className="md:col-span-2">
            <Field label="Message" error={errors.message?.message}>
              <textarea
                className={`${inputCls} min-h-[120px] resize-y`}
                rows={4}
                {...register("message")}
              />
            </Field>
          </div>

          <div className="md:col-span-2 flex items-center justify-between border-t border-border pt-8">
            <p className="text-[11px] tracking-[0.18em] uppercase text-muted-foreground font-light">
              Response within 24 hours.
            </p>
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center gap-3 bg-foreground text-background px-7 py-3 text-[11px] tracking-[0.28em] uppercase font-light transition-all hover:gap-5 disabled:opacity-50"
            >
              <span>{submitting ? "Sending" : "Submit RFQ"}</span>
              <span className="text-turquoise">→</span>
            </button>
          </div>
        </form>
      </Reveal>
    </section>
  );
}

/* ---------------- FOOTER ---------------- */

function FooterStrip() {
  return (
    <footer className="border-t border-border mt-16">
      <div className="mx-auto max-w-7xl px-6 md:px-10 py-8 flex flex-col md:flex-row items-center justify-between gap-3 text-[11px] tracking-[0.18em] uppercase font-light text-muted-foreground">
        <a
          href="mailto:info@fsametals.com"
          className="transition-colors hover:text-gold"
        >
          info@fsametals.com
        </a>
        <span className="opacity-70">Global · Operations Worldwide</span>
        <span className="opacity-70">
          © {new Date().getFullYear()} FSA Global Metals
        </span>
      </div>
    </footer>
  );
}

/* ---------------- FORM HELPERS ---------------- */

const inputCls =
  "w-full bg-transparent border-0 border-b border-border px-0 py-2 text-sm font-light text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-turquoise transition-colors";

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="block text-[10px] tracking-[0.24em] uppercase text-muted-foreground font-light mb-2">
        {label}
      </span>
      {children}
      {error && (
        <span className="block mt-2 text-[11px] text-destructive font-light">
          {error}
        </span>
      )}
    </label>
  );
}
