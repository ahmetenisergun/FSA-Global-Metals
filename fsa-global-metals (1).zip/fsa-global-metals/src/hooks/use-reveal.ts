import { useEffect, useRef, useState } from "react";

/**
 * Toggles `is-visible` when the element enters the viewport.
 * Falls back to visible after a short delay so nothing stays hidden if IO misses.
 * Honors prefers-reduced-motion.
 */
export function useReveal<T extends HTMLElement = HTMLDivElement>(options?: {
  threshold?: number;
  rootMargin?: string;
  once?: boolean;
}) {
  const ref = useRef<T | null>(null);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const reduce =
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setVisible(true);
      return;
    }

    // If element is already in / above viewport on mount, reveal immediately.
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight && rect.bottom > 0) {
      setVisible(true);
    }

    const obs = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            setVisible(true);
            if (options?.once !== false) obs.unobserve(e.target);
          } else if (options?.once === false) {
            setVisible(false);
          }
        }
      },
      {
        threshold: options?.threshold ?? 0,
        rootMargin: options?.rootMargin ?? "0px 0px 0px 0px",
      },
    );
    obs.observe(el);

    // Safety fallback — if for any reason IO never reports, reveal after 1.2s.
    const t = window.setTimeout(() => setVisible(true), 1200);

    return () => {
      obs.disconnect();
      window.clearTimeout(t);
    };
  }, [options?.threshold, options?.rootMargin, options?.once]);

  return { ref, visible };
}
