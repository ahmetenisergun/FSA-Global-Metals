import { useEffect, useState } from "react";

/**
 * Tracks raw window scrollY (px). Updates on rAF for smoothness.
 */
export function useScrollY() {
  const [y, setY] = useState(0);

  useEffect(() => {
    let raf = 0;
    let pending = false;
    const update = () => {
      pending = false;
      setY(window.scrollY);
    };
    const onScroll = () => {
      if (!pending) {
        pending = true;
        raf = requestAnimationFrame(update);
      }
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  return y;
}
